<?php

class controller {

    public $app;

    public function __construct($app) {

        $this->app = $app;

    }

}

?>
