<?php

return [

    'name' => 'content',

    'menu' => [
        'content' => [
            'icon' => '~/img/content.svg',
            'name' => 'Content',
            'url' => 'content',
            'active' => 'content(/*)?',
            'order' => 10
        ]
    ]

];

?>
