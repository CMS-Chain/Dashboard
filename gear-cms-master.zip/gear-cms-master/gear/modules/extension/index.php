<?php

return [

    'name' => 'extension',

    'menu' => [
        'extensions' => [
            'icon' => '~/img/extensions.svg',
            'name' => 'Extend',
            'url' => 'extensions',
            'active' => 'extensions(/*)?',
            'order' => 20
        ]
    ]

];

?>
